const scriptURL = "PASTE_URL_WEB_APP_GOOGLE_SCRIPT_DI_SINI";
const form = document.getElementById("rsvpForm");

form.addEventListener("submit", e => {
  e.preventDefault();
  fetch(scriptURL, { method: "POST", body: new FormData(form) })
    .then(() => alert("RSVP berhasil dikirim 🤍"))
    .catch(() => alert("Gagal mengirim data"));
  form.reset();
});
